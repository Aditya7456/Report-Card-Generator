/*
Author:     ADITYA PRAJAPATI
Topic:      To write a C program to generate the report card of a student based on his marks
            secured in the final examination. 

*/
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
int main (){

    
    int standard;
    char section;
    char name[30];
    float mathematics,english,hindi,science,socialScience,Total;

    printf("                     Welcome to the Portal of Javahar Navodya vidyalya .\n\n");

    printf("enter your name : ");
    scanf("%[^\n]s",name);
    while((getchar())!='\n');

    printf("enter the section of the class : ");
    scanf("%c",&section);
    while((getchar())!='\n');

    printf("enter the standard of the class : ");
    scanf("%d",&standard);
    while((getchar())!='\n');

    printf("enter the mathematics marks : ");
    scanf("%f",&mathematics);
    while((getchar())!='\n');

    printf("enter the english marks : ");
    scanf("%f",&english);
    while((getchar())!='\n');

    printf("enter the hindi marks : ");
    scanf("%f",&hindi);
    while((getchar())!='\n');

    printf("enter the science marks : ");
    scanf("%f",&science);
    while((getchar())!='\n');

    printf("enter the socialScience marks : ");
    scanf("%f",&socialScience);
    while((getchar())!='\n');

    Total = hindi+science+english+socialScience+mathematics; 

    printf("\n\n------------------------------------------------------------------------------------------\n");
    printf("                                     Javahar Navodaya Vidyalaya\n");
    printf("                                         Annual Report card");
    printf("\n\n\nName :      %s",name);
    printf("\nStandard :\t %d",standard);
    printf("\nSection :\t '%c'",section);
    printf("\n\n\nMarks Secured Out of 100\n");
    
    printf("Mathematics :     %.2f\n",mathematics);

         
    printf("Science :         %0.2f\n",science);

   
    printf("English :         %0.2f\n",english);
    

       
         printf("Hindi :           %0.2f\n",hindi);

         
         
         printf("Social :          %0.2f\n\n\n",socialScience);

         printf("Total Marks Secured :              %0.2f\n",Total); 
         
    if (Total>500 || Total<0 )
    {
        exit(0);
    }
    else
    {
        if (Total>=450 && Total<=500)
        {
            printf("Grade :                               'A'"); 
        }
        else if (Total>=400 && Total<=499)
        {
            printf("Grade :                              'B'");
        }
         else if (Total>=350 && Total<=399)
        {
            printf("Grade :                              'C'"); 
        }
         else if (Total>=300 && Total<=349)
        {
            printf("Grade :                              'D'");
        }
         else if (Total>=200 && Total<=299)
        {
            printf("Grade:                               'E'");
        }
         else
        {   
            printf("Grade:                               'F'");
        }
        
     } 
    
    printf("\n\n------------------------------------------------------------------------------------------\n");
      getch();
 return 0;   
}